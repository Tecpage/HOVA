Y – Launcher (Web)

Ordnerstruktur (empfohlen):
- iCloud Drive/Y/
  - Start_Y.command
  - Tacheles/
  - IPRO/
  - System/
    - Launcher/

Start:
1) Stelle sicher, dass `Start_Y.command` im Ordner `Y/` liegt.
2) Doppelklick auf `Start_Y.command` (oder per Hammerspoon/Shortcut ausführen).
3) Der Launcher öffnet sich in einem neuen Chrome-Fenster.

Einmalig (falls nötig):
- `python3 -m pip install --user pyyaml`

Hinweis:
- Der Launcher startet Apps per Start-Skripten in den jeweiligen Projektordnern.
