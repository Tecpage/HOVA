const TACHELES_URL = `http://127.0.0.1:8010/dashboard/`;
const IPRO_URL     = `http://127.0.0.1:8020/dashboard/`;

const $tabs = document.getElementById('tabs');
const $stage = document.getElementById('stage');
const $btnAdd = document.getElementById('btnAdd');
const $menu = document.getElementById('menu');

let tabs = [];
let activeId = null;

function nowBust(url){
  const u = new URL(url);
  u.searchParams.set('v', String(Date.now()));
  return u.toString();
}

function makeId(){ return 't' + Date.now() + '_' + Math.random().toString(16).slice(2); }

function save(){
  try{
    localStorage.setItem('ytabs.tabs', JSON.stringify(tabs));
    localStorage.setItem('ytabs.active', activeId || '');
  }catch(e){}
}

function load(){
  try{
    const t = JSON.parse(localStorage.getItem('ytabs.tabs') || '[]');
    const a = localStorage.getItem('ytabs.active') || '';
    if (Array.isArray(t)) tabs = t;
    if (a) activeId = a;
  }catch(e){}
}

function render(){
  $tabs.innerHTML = '';
  // tab buttons
  for(const t of tabs){
    const el = document.createElement('div');
    el.className = 'tab' + (t.id === activeId ? ' active' : '');
    el.innerHTML = `<span>${t.title}</span><button class="x" title="Schließen">×</button>`;
    el.addEventListener('click', (ev) => {
      if(ev.target && ev.target.classList.contains('x')) return;
      setActive(t.id);
    });
    el.querySelector('.x').addEventListener('click', (ev) => {
      ev.stopPropagation();
      closeTab(t.id);
    });
    $tabs.appendChild(el);
  }

  // iframes
  const frames = $stage.querySelectorAll('iframe.frame');
  frames.forEach(f => f.classList.remove('active'));
  const f = document.getElementById('frame_' + activeId);
  if (f) f.classList.add('active');
}

function setActive(id){
  activeId = id;
  save();
  render();
}

function closeTab(id){
  const idx = tabs.findIndex(t => t.id === id);
  if (idx < 0) return;

  // remove iframe
  const f = document.getElementById('frame_' + id);
  if (f) f.remove();

  tabs.splice(idx, 1);

  if (activeId === id){
    if (tabs[idx]) activeId = tabs[idx].id;
    else if (tabs[idx-1]) activeId = tabs[idx-1].id;
    else activeId = tabs[0]?.id || null;
  }

  save();
  render();
}

function openTab(title, url){
  // already open same url? -> just activate
  const existing = tabs.find(t => t.url === url);
  if (existing){
    setActive(existing.id);
    return;
  }

  const id = makeId();
  tabs.push({ id, title, url });
  activeId = id;

  const iframe = document.createElement('iframe');
  iframe.className = 'frame active';
  iframe.id = 'frame_' + id;
  iframe.src = nowBust(url);
  iframe.loading = 'eager';
  $stage.appendChild(iframe);

  // deactivate others
  const frames = $stage.querySelectorAll('iframe.frame');
  frames.forEach(f => { if(f.id !== iframe.id) f.classList.remove('active'); });

  save();
  render();
}

function openFromKey(key){
  if (key === 'tacheles') openTab('Tacheles', TACHELES_URL);
  else if (key === 'ipro') openTab('IPRO', IPRO_URL);
  else if (key === 'url'){
    const u = prompt('URL öffnen:');
    if (!u) return;
    openTab(u.replace(/^https?:\/\//,'').slice(0,40) || 'URL', u);
  }
}

function menuToggle(){
  $menu.classList.toggle('open');
}
$btnAdd.addEventListener('click', (e) => { e.stopPropagation(); menuToggle(); });
document.addEventListener('click', () => $menu.classList.remove('open'));
$menu.querySelectorAll('.menuItem').forEach(btn => {
  btn.addEventListener('click', () => {
    $menu.classList.remove('open');
    openFromKey(btn.dataset.open);
  });
});

// Init
load();

// Wenn nichts gespeichert: immer mit Tacheles starten
if (!tabs.length){
  openFromKey('tacheles');
} else {
  // frames neu bauen
  for(const t of tabs){
    const iframe = document.createElement('iframe');
    iframe.className = 'frame' + (t.id === activeId ? ' active' : '');
    iframe.id = 'frame_' + t.id;
    iframe.src = nowBust(t.url);
    $stage.appendChild(iframe);
  }
  if (!activeId && tabs[0]) activeId = tabs[0].id;
  save();
  render();
}

/* === YTABS_OPEN_PARAM_PATCH_BEGIN === */
// Init
load();

const params = new URLSearchParams(location.search);
const forceOpen = (params.get('open') || '').toLowerCase();
const allowed = new Set(['tacheles','ipro','url']);

if (tabs && tabs.length) {
  // frames neu bauen
  for(const t of tabs){
    const iframe = document.createElement('iframe');
    iframe.className = 'frame' + (t.id === activeId ? ' active' : '');
    iframe.id = 'frame_' + t.id;
    iframe.src = nowBust(t.url);
    $stage.appendChild(iframe);
  }
  if (!activeId && tabs[0]) activeId = tabs[0].id;
  save();
  render();

  if (allowed.has(forceOpen)) {
    openFromKey(forceOpen);
  }
} else {
  if (allowed.has(forceOpen)) {
    openFromKey(forceOpen);
  } else {
    openFromKey('tacheles');
  }
}
/* === YTABS_OPEN_PARAM_PATCH_END === */

