// tenant_status
const TENANTS_JSON_PATH = "./data/tenants_indexation.json?v=" + Date.now();
const PAYMENTS_JSON_PATH = "./data/payments_rent_roll.json?v=" + Date.now();
const BUILD_META_PATH = "./data/build_meta.json?v=" + Date.now();
const QUALITY_PATH = "./data/quality_report.json?v=" + Date.now();

function $(id){return document.getElementById(id);}
function safe(x){return (x===null||x===undefined)?"":String(x);}
function setStatus(m){var s=$('status'); if(s) s.textContent=m;}
function banner(cls,msg){var b=$('healthBanner'); if(!b) return; b.classList.remove('ok','warn','fail'); if(cls) b.classList.add(cls); b.textContent=msg;}
function showDebug(obj){var d=$('debugLog'); if(!d) return; d.style.display='block'; d.textContent=(typeof obj==='string')?obj:JSON.stringify(obj,null,2);} 

function tenantNoKey(no){const s=safe(no).trim(); if(!s||s==='—') return [2, Number.MAX_SAFE_INTEGER, '']; const n=parseInt(s,10); if(!Number.isNaN(n)) return [0,n,s]; return [1, Number.MAX_SAFE_INTEGER-1, s.toLowerCase()];}
function sortByTenantNo(rows){return [...rows].sort((a,b)=>{const ka=tenantNoKey(a.tenant_no), kb=tenantNoKey(b.tenant_no); if(ka[0]!==kb[0]) return ka[0]-kb[0]; if(ka[1]!==kb[1]) return ka[1]-kb[1]; return safe(a.name).localeCompare(safe(b.name));});}
function fmtEUR(x){const n=Number(x); if(!Number.isFinite(n)) return '—'; return n.toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2});}
function deltaLabel(delta){if(delta===null||delta===undefined||delta==='') return '—'; const n=Number(delta); if(!Number.isFinite(n)) return '—'; return n.toFixed(2)+'%';}

function formatIndexation(ix){
  if(!ix) return '—';

  var vpi = (TENANTS && TENANTS.current_vpi) ? TENANTS.current_vpi : {};
  var curMonth = safe(vpi.month) || '—';
  var curVal = (vpi.value===null||vpi.value===undefined) ? null : Number(vpi.value);

  var baseMonth = safe(ix.base_index_month) || '—';
  var baseVal = (ix.base_index_value===null||ix.base_index_value===undefined) ? null : Number(ix.base_index_value);
  var thr = (ix.threshold_percent===null||ix.threshold_percent===undefined) ? null : Number(ix.threshold_percent);
  var baseNet = (ix.base_net_amount===null||ix.base_net_amount===undefined) ? null : Number(ix.base_net_amount);
  var cur = safe(ix.currency) || 'EUR';

  var delta = null;
  if(curVal!==null && baseVal!==null && Number.isFinite(curVal) && Number.isFinite(baseVal) && baseVal>0){
    delta = ((curVal/baseVal)-1.0)*100.0;
  }

  var badge = '';
  if(delta===null || thr===null || !Number.isFinite(thr)){
    badge = '<div class="pill warn">Prüfung nicht möglich</div>';
  } else if(delta > thr){
    badge = '<div class="pill needs-action">Handlungsbedarf ('+delta.toFixed(2)+'%)</div>';
  } else {
    badge = '<div class="pill ok">Kein Handlungsbedarf ('+delta.toFixed(2)+'%)</div>';
  }

  var proposal = '—';
  if(delta!==null && thr!==null && Number.isFinite(thr) && delta>thr && baseNet!==null && baseVal!==null && curVal!==null && baseVal>0){
    var newNet = baseNet*(curVal/baseVal);
    if(Number.isFinite(newNet)) proposal = fmtEUR(newNet) + ' ' + cur;
  }

  var parts = [];
  parts.push(badge);
  parts.push('<div><b>Schwelle:</b> '+(thr!==null&&Number.isFinite(thr)?thr:'—')+'%</div>');
  parts.push('<div><b>Basis:</b> '+baseMonth+' = '+(baseVal!==null&&Number.isFinite(baseVal)?String(baseVal):'—')+'</div>');
  parts.push('<div><b>Basisnetto:</b> '+(baseNet!==null&&Number.isFinite(baseNet)?(fmtEUR(baseNet)+' '+cur):'—')+'</div>');
  parts.push('<div><b>Aktuell:</b> '+curMonth+' = '+(curVal!==null&&Number.isFinite(curVal)?String(curVal):'—')+'</div>');
  parts.push('<div><b>Vorschlag neu:</b> '+proposal+'</div>');
  if(ix.notes){ parts.push('<div class="muted">'+safe(ix.notes)+'</div>'); }
  return parts.join('');
}


async function loadJson(url){const r=await fetch(url,{cache:'no-store'}); if(!r.ok) throw new Error('HTTP '+r.status+' '+url); return await r.json();}

let TENANTS=null, PAYMENTS=null, META=null, QUALITY=null;
let VIEW='index';

async function loadAll(){
  try{
    setStatus('build_meta…'); META=await loadJson(BUILD_META_PATH);
    var bi=$('buildInfo'); if(bi && META){ var fp12=(META.fingerprint)?String(META.fingerprint).slice(0,12):'—'; var ga=META.generated_at?String(META.generated_at).replace('T',' ').replace('+00:00','Z'):'—'; var vm=(META.vpi_month!==undefined&&META.vpi_month!==null)?String(META.vpi_month):'—'; var vv=(META.vpi_value!==undefined&&META.vpi_value!==null)?String(META.vpi_value):'—'; bi.textContent='Build: '+fp12+' · '+ga+' · VPI '+vm+' = '+vv; }
    setStatus('tenants…'); TENANTS=await loadJson(TENANTS_JSON_PATH);
    setStatus('payments…'); PAYMENTS=await loadJson(PAYMENTS_JSON_PATH);
    setStatus('quality…'); QUALITY=await loadJson(QUALITY_PATH);
    const fp=(META&&META.fingerprint)?String(META.fingerprint).slice(0,12):'—';
    const warns=(QUALITY&&QUALITY.warnings)?QUALITY.warnings.length:0;
    var summary=[];
    if(warns>0 && QUALITY && Array.isArray(QUALITY.warnings)) {
      for(var i=0;i<QUALITY.warnings.length;i++){
        var w=QUALITY.warnings[i]||{};
        if(w.code==='TENANT_NO_MISSING') summary.push('Miet-Nr. fehlt bei '+String((w.tenant_ids||[]).length)+' Mieter(n).');
        else if(w.code==='PAYMENT_TOTAL_MISMATCH') summary.push('Zahlungen: Summe Bausteine ≠ Netto (Rundung/Erfassung prüfen).');
        else summary.push(String(w.code||'WARN')+': '+String(w.message||''));
        if(summary.length>=3) break;
      }
    }
    if(warns>0) banner('warn','OK mit Hinweisen – Build '+fp+(summary.length?('\n• '+summary.join('\n• ')):''));
    else banner('ok','OK – Build '+fp);
    showDebug({build_meta:META, quality:QUALITY});
    return true;
  } catch(e){
    banner('fail','FEHLER – siehe Debug');
    showDebug({error:(e&&e.message)?e.message:String(e), url:location.href});
    setStatus('Fehler');
    return false;
  }
}

function setHead(cols){var tr=$('theadRow'); if(!tr) return; tr.innerHTML=cols.map(c=>'<th>'+c+'</th>').join('');}

function renderIndex(){
  setHead(['Miet-Nr.','Status','Name','Δ VPI %','Index-Status','Neuer Netto-Betrag','Indexierung (Details)']);
  var tb=$('tbody'); if(!tb) return; tb.innerHTML='';
  var rows=sortByTenantNo((TENANTS&&TENANTS.rows)?TENANTS.rows:[]);
  for(var i=0;i<rows.length;i++){
    var r=rows[i];
    var idx = safe(r.status);
    var idxLabel = (idx==='OK')?'Kein Handlungsbedarf':(idx==='HANDLUNGSBEDARF')?'Handlungsbedarf':'—';
    var newNet = (r.new_net_amount===null||r.new_net_amount===undefined)?'—':(fmtEUR(r.new_net_amount)+' EUR');
    var tr=document.createElement('tr');
    tr.innerHTML='<td>'+ (safe(r.tenant_no)||'—') +'</td><td>'+safe(r.tenant_status)+'</td><td>'+safe(r.name)+'</td><td>'+deltaLabel(r.delta_vpi_percent)+'</td><td>'+idxLabel+'</td><td style="text-align:right">'+newNet+'</td><td>'+formatIndexation(r.indexation_details)+'</td>';
    tb.appendChild(tr);
  }
  var vpi=(TENANTS&&TENANTS.current_vpi)?TENANTS.current_vpi:{};
  var vi=$('vpiInfo'); if(vi) vi.textContent='VPI (2020=100) aktuell: '+(safe(vpi.month)||'—')+' = '+(vpi.value!==null&&vpi.value!==undefined?safe(vpi.value):'—');
  var kt=$('kpiTotal'); if(kt) kt.textContent='Mieter: '+rows.length;
  var ki=$('kpiIndexed'); if(ki) ki.textContent='Indexiert: '+rows.filter(x=>x.indexation_details).length;
  var kh=$('kpiTriggered'); if(kh) kh.textContent='Handlungsbedarf: '+rows.filter(x=>x.status==='HANDLUNGSBEDARF').length;
}

function renderPayments(){
  setHead(['Miet-Nr.','Status','Name','Kaltmiete','BK/NK','Heizung','Lager/Keller','Parkplatz','Reinigung','Poststelle','Verwaltergeb.','sonstige DL','netto','brutto']);
  var tb=$('tbody'); if(!tb) return; tb.innerHTML='';
  var rows=sortByTenantNo((PAYMENTS&&PAYMENTS.rows)?PAYMENTS.rows:[]);
  for(var i=0;i<rows.length;i++){
    var r=rows[i];
    var tr=document.createElement('tr');
    tr.innerHTML='<td>'+ (safe(r.tenant_no)||'—') +'</td><td>'+safe(r.tenant_status)+'</td><td>'+safe(r.name)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.base_rent_net)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.bk_nk)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.heating)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.storage_cellar)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.parking)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.cleaning)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.mailroom)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.management_fee)+'</td>'+
      '<td style="text-align:right">'+fmtEUR(r.other_services)+'</td>'+
      '<td style="text-align:right"><b>'+fmtEUR(r.total_net)+'</b></td>'+
      '<td style="text-align:right"><b>'+fmtEUR(r.total_gross)+'</b></td>';
    tb.appendChild(tr);
  }
  var vi=$('vpiInfo'); if(vi) vi.textContent='Payments (Rent Roll) – Periode: '+((PAYMENTS&&PAYMENTS.period)?PAYMENTS.period:'—');
  var kt=$('kpiTotal'); if(kt) kt.textContent='Mieter: '+rows.length;
  var ki=$('kpiIndexed'); if(ki) ki.textContent='Periode: '+((PAYMENTS&&PAYMENTS.period)?PAYMENTS.period:'—');
  var sum=rows.reduce((s,x)=>s+(Number(x.total_net)||0),0);
  var kh=$('kpiTriggered'); if(kh) kh.textContent='Summe netto: '+fmtEUR(sum)+' EUR';
}

function wire(){
  var bi=$('btnViewIndex'); if(bi) bi.onclick=function(){VIEW='index'; renderIndex();};
  var bp=$('btnViewPayments'); if(bp) bp.onclick=function(){VIEW='payments'; renderPayments();};
  var br=$('btnReload'); if(br) br.onclick=function(){location.reload();};
  var cb=$('btnCopyBuild'); if(cb) cb.onclick=async function(){ try{ var bi=$('buildInfo'); var txt=bi?bi.textContent:''; if(navigator.clipboard&&txt){ await navigator.clipboard.writeText(txt); setStatus('Build kopiert'); } else { setStatus('Clipboard nicht verfügbar'); } }catch(e){ setStatus('Copy fehlgeschlagen'); } };
}

(async function(){
  var ok = await loadAll();
  wire();
  if(ok) renderIndex();
})();
